import { useState } from "react";
import "./App.css";

const phrases = [
  "No",
  "No",
  "¿Estás segura?",
  "Piénsalo de nuevo",
  "Eres un panda",
  "Los pandas deben dar click al boton de la izquierda",
  "Sigues sin decir que si...",
  "No me quieres",
  "Enserio no te importo",
  "Di que si o lloro",
  "Estoy llorando Camila",
  "Camila sigo llorando y aún no dices que si",
  "De verdad me vas a hacer sentir triste",
  "Que mala eres Camila",
  "Mi corazon se rompio...",
  "Rompiste mi corazón",
  "Ya dale al boton de sí",
];

function App() {
  const [noCount, setNoCount] = useState(0);
  const [yesPressed, setYesPressed] = useState(false);
  const yesButtonSize = noCount * 20 + 16;

  function handleNoClick() {
    setNoCount(noCount + 1);
  }

  function getNoButtonText() {
    return phrases[Math.min(noCount, phrases.length - 1)];
  }

  const noButtonStyle = {
    backgroundColor: noCount > 0 ? "#ff6961" : "#f0f0f0",
    color: noCount > 0 ? "#f0f0f0" : "#333",
    borderRadius: "50px",
    padding: "10px 20px",
    fontSize: "16px",
    cursor: "pointer",
  };

  const yesButtonStyle = {
    backgroundColor: "#90EE90",
    color: "#000000",
    borderRadius: "50px",
    padding: "10px 20px",
    fontSize: yesButtonSize,
    cursor: "pointer",
  };

  return (
    <div className="App">
      <div
        className="container"
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "100vh",
        }}
      >
        {yesPressed ? (
          <>
            <img
              alt="panda feliz"
              src="https://tenor.com/es/view/bubu-dudu-love-cute-gif-27370319.gif"
            />
            <div
              style={{ fontSize: "3em", fontWeight: "bold", color: "black" }}
            >
              ¡Yeiiii! Te quiero mucho Baby
            </div>
          </>
        ) : (
          <>
            <img
              alt="panda triste"
              src="https://tenor.com/es/view/hmp-gif-26064815.gif"
            />
            <div
              style={{
                fontSize: "3em",
                fontWeight: "bold",
                color: "black",
                textAlign: "center",
                marginBottom: "20px",
              }}
            >
              ¿Quieres ser mi San Valentín?
            </div>
            <div>
              <button
                className="yesButton"
                style={yesButtonStyle}
                onClick={() => setYesPressed(true)}
              >
                Sí
              </button>
              <button
                onClick={handleNoClick}
                className="noButton"
                style={noButtonStyle}
              >
                {getNoButtonText()}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default App;
